
public class MerInfo {
	
	private String name;
	private int price;

	public MerInfo() {
		// TODO Auto-generated constructor stub
	}
	
	public MerInfo(String name, int price) {
		this.name = name;
		this.price = price;
	}
	
	public int getPrice() {
		return price;
	}
	public void setPrice(int uPrice) {
		this.price = uPrice;
	}	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	

	
	
}
