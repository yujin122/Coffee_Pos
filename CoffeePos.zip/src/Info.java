// 메뉴정보
public class Info{
	
	public Info() { }
	
	public Info(MerInfo[] merInfo) {
		
		merInfo[0] = new MerInfo("아메리카노(hot)",4500);
		merInfo[1] = new MerInfo("아메리카노(ice)",5000);
		merInfo[2] = new MerInfo("카페라떼(hot)",5000);
		merInfo[3] = new MerInfo("카페라떼(ice)",5500);
		merInfo[4] = new MerInfo("카페모카(hot)",5000);
		merInfo[5] = new MerInfo("카페모카(ice)",5500);
		merInfo[6] = new MerInfo("바닐라라떼(hot)",5500);
		merInfo[7] = new MerInfo("바닐라라떼(ice)",6000);
		merInfo[8] = new MerInfo("콜드브루(ice)",6000);
		
		merInfo[9] = new MerInfo("민트티(hot)",4500);
		merInfo[10] = new MerInfo("민트티(ice)",5000);
		merInfo[11] = new MerInfo("얼그레이티(hot)",5000);
		merInfo[12] = new MerInfo("버블티(ice)",5500);
		merInfo[13] = new MerInfo("레몬에이드(ice)",5000);
		merInfo[14] = new MerInfo("탄산수(ice)",5500);
		merInfo[15] = new MerInfo("망고스무디(ice)",5500);
		merInfo[16] = new MerInfo("우유(ice)",6000);
		
		merInfo[17] = new MerInfo("치즈케이크",4500);
		merInfo[18] = new MerInfo("초코케이크",5000);
		merInfo[19] = new MerInfo("샌드위치",5000);
		merInfo[20] = new MerInfo("쿠키",5500);
		merInfo[21] = new MerInfo("도넛",5000);
		merInfo[22] = new MerInfo("머핀",5500);
		merInfo[23] = new MerInfo("아이스크림",5500);
		merInfo[24] = new MerInfo("샐러드",6000);
	}	
}